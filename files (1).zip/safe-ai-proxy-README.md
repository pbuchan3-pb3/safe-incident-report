# SAFE AI Proxy

The single abstraction point for all AI/speech services behind the S.A.F.E. Incident Report app.
No AI or speech-to-text API keys ever live in the browser.

```
Browser  ->  SAFE AI Proxy (this Worker)  ->  Speech Provider  ->  Transcript  ->  Claude extraction  ->  Incident Report
```

## Why this exists

The Incident Report app calls one function — `transcribeRecording(audioBlob)` — and gets a
transcript back. It does not know or care which provider produced it. Whisper today; Azure,
Google, or AWS tomorrow. Swapping providers is a server-side config change with zero app changes.

## Layout

```
src/
  index.js               Worker entry: routing, CORS, app-token gate, error normalization
  lib/http.js            CORS + JSON helpers + origin allowlist
  lib/errors.js          Error types (public message vs. server-only detail)
  providers/index.js     Provider registry — the ONE place a provider is chosen
  providers/whisper.js   OpenAI Whisper (today's default)
  providers/azure.js     stub — implement to the contract to enable
  providers/google.js    stub
  providers/aws.js       stub
  services/transcribe.js POST /transcribe — provider-agnostic
  services/extract.js    POST /extract — Claude proxy (retires the browser Anthropic key)
client/
  transcription-client.js  transcribeRecording(blob) — drop into the app
test/
  proxy.logic.test.js    pure-logic tests (12 checks, no network)
wrangler.toml            config + secret instructions
```

## Deploy (Cloudflare Workers — free tier, no credit issues)

```bash
npm install -g wrangler
wrangler login
wrangler secret put OPENAI_API_KEY        # Whisper
wrangler secret put ANTHROPIC_API_KEY     # Claude extraction
wrangler secret put APP_TOKEN             # shared token the app sends in X-App-Token
wrangler deploy
```

Then set `PROXY_BASE` and `APP_TOKEN` in `client/transcription-client.js` to your Worker URL
and the token you chose.

## Swapping the speech provider (the whole point)

1. Implement `transcribe(audio, mimeType, opts, env)` in e.g. `providers/azure.js` to return `{ text }`.
2. Uncomment its import + registry line in `providers/index.js`.
3. `wrangler secret put` any keys it needs, and set `SPEECH_PROVIDER = "azure"` in `wrangler.toml`.
4. `wrangler deploy`. The app and the Incident Report code are untouched.

## Security notes (candid)

- Provider keys live only in Worker secrets — never in the client bundle.
- CORS is locked to `ALLOWED_ORIGINS`; other origins get `null`.
- `X-App-Token` is a compensating control, not user authentication. It is present in the
  client bundle, so treat it as abuse-resistance (cheap to rotate, grants no direct provider
  access), not identity. Pair it with a Cloudflare rate-limit rule. A proper next step is
  per-user auth + per-user quotas.
- The proxy logs metadata only (provider, bytes, ms, char count) — never audio, never transcript text.
- Upload capped at 25 MB (Whisper's limit); a 12-minute Opus recording is far under.

## App integration (pending in the Incident Report file)

Inside `recordingGenerateDraft()`, replace reliance on live SpeechRecognition with:

```js
import { transcribeRecording, TranscriptionError } from './transcription-client.js';

// blob already saved to IndexedDB before this runs
try {
  const { transcript } = await transcribeRecording(audioBlob);
  diag.transcriptSource = 'stt';           // vendor-neutral on purpose
  // ... feed transcript to existing AI extraction ...
} catch (e) {
  if (e.code === 'offline') {
    diag.transcriptionPending = true;      // audio kept; "Transcribe now" when back online
  } else {
    diag.fallbackReason = e.code;          // 'no_speech_detected' | 'stt_failed' | ...
  }
}
```

Live SpeechRecognition stays only as an on-screen preview while recording.
