// Provider-agnostic transcription client for the Incident Report app.
// The app calls transcribeRecording(blob); it never knows which speech
// provider the proxy uses. Swapping providers is a proxy-side change only.

const PROXY_BASE = 'https://safe-ai-proxy.YOUR-SUBDOMAIN.workers.dev';
const APP_TOKEN  = '__SET_AT_DEPLOY__'; // public app token; real secrets live in the proxy

export class TranscriptionError extends Error {
  constructor(code, message, status) {
    super(message);
    this.name = 'TranscriptionError';
    this.code = code;          // 'offline' | 'empty_audio' | 'no_speech_detected' | 'stt_failed' | ...
    this.status = status || 0;
  }
}

// Recover the transcript from a recorded audio blob.
// Returns { transcript, durationMs }. Throws TranscriptionError.
//   code === 'offline'           -> network unreachable; caller marks transcription pending.
//   code === 'no_speech_detected'-> audio had no discernible speech.
export async function transcribeRecording(audioBlob, opts = {}) {
  if (!audioBlob || audioBlob.size === 0) throw new TranscriptionError('empty_audio', 'No audio to transcribe');

  let res;
  try {
    res = await fetch(`${PROXY_BASE}/transcribe`, {
      method: 'POST',
      headers: { 'Content-Type': audioBlob.type || 'audio/webm', 'X-App-Token': APP_TOKEN },
      body: audioBlob,
    });
  } catch (networkErr) {
    // fetch rejects only on network failure — the stadium-offline case.
    throw new TranscriptionError('offline', 'Network unreachable — transcription pending', 0);
  }

  if (!res.ok) {
    let payload = {};
    try { payload = await res.json(); } catch (_) {}
    throw new TranscriptionError(payload.code || 'stt_failed', payload.error || `HTTP ${res.status}`, res.status);
  }

  const data = await res.json();
  if (!data.transcript) throw new TranscriptionError('no_speech_detected', 'No speech detected in recording');
  return { transcript: data.transcript, durationMs: data.durationMs };
}
